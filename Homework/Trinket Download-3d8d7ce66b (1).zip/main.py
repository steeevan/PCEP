age = 13
type(age)
print(age)
print(type)
#??? I don't know the "type()" part

length = 5
width = 10
area = length*width
print(area)

num1 = 15
num2 = 20
num1 < num2
print(num1<num2)

#var = "count"
#"count" += 3
#"count" *= 2
#print(var)
#ok i legit have no clue how to do this one

name = "Jasper"
len(name)
print(len)
#idk if i did it correctly

notebook_price = 2.50
pencil_price = 0.75
num_notebooks = 8
num_pencils = 5
total_notebook_cost = notebook_price*num_notebooks
total_pencil_cost = pencil_price*num_pencils
total = total_notebook_cost + total_pencil_cost
print(total)

fruit_1 = "apple"
fruit_2 = "banana"
"apple"!="banana"
print("apple"!="banana")
#idk how to do this

distance = 100
distance -= 20
distance**=2
print(distance)

is_happy = True
int(is_happy)
print(int)
#idk how to do this one

score1 = 85
score2 = 92
score3 = 78
total_score = 85+92+79
average_score = total_score/3
print(average_score)

sum_result = 10+15
product_result = 5*5
sum_result >= product_result
print(sum_result >= product_result)

value = 7
value*=4
value+=12
print(value)

temperature = 98.6
str(temperature)
print(temperature)
#idk how to do this correctly

total_amount = 500
num_friends = 3
amount_per_friend = total_amount/num_friends
remaining_amount = total_amount%num_friends
print(amount_per_friend)
print(remaining_amount)

product_result = 8*-2
abs_value = abs(product_result)
print(abs_value)





















































































print(leng)











