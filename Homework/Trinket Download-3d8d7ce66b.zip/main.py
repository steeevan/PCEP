integer_var = 100
float_var = 1.1
print(integer_var+float_var)

long_var = 10^10
complex_var = 3 + 4j
print(long_var)
print(complex_var)

string_var = "Jasper C Wang"
print(string_var[0:6])
string_var2 = "Jasper, welcome to the Python class!"
print(string_var2)

num_list = [1,2,3,4,5]
num_list.append(1.2)
print(num_list)

fruit_tuple = ("kiwi","strawberry","watermelon")
print(fruit_tuple[2])

student_dict = {"name":"Jasper","age":13,"grade":"8th","city":"Chino Hills"}
print(student_dict["age"])

bool_var1 = True
bool_var2 = False
print(bool_var1)














student
